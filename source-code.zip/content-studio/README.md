# 内容工坊 · GitHub Pages 独立版

无需 ChatGPT 登录的自媒体内容工作台。保留选题、对标材料导入、小红书/抖音/X独立草稿、模板图文、视频分镜、审核排期、导出与表现记录。

## 数据与功能

- 内容仅保存在当前浏览器 localStorage，清理站点数据后会丢失；请在“业务与设置”导出 JSON 备份。
- 不含原网站的个人数据、服务端代码、密钥或云端资源。不会自动同步原站点资料。
- AI 可通过复制提示词与导入 JSON 使用；未接入在线 AI、热点抓取、封面上传、自动发布或知识库。
- `guide.html` 提供无需运行 JavaScript 的公开功能说明，适合其他 AI 对话读取。

## 部署

已包含 `docs/` 构建产物。上传到新建的公开仓库后，在 Settings → Pages 中选择 Deploy from a branch，分支 main、目录 /docs，保存。

也可在 Pages 中选择 GitHub Actions，由仓库中的工作流部署 `docs/`。

## 本地开发

使用 Node.js 22.13 或更新版本，执行 `npm install`、`npm run dev`。修改后执行 `npm run check`、`npm run build`，将更新后的 `docs/` 一同提交。
