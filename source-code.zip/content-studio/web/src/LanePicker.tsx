import {useState} from 'react';
export const lanes:Record<string,string[]>={
 '母婴育儿':['亲子英语','英语启蒙','亲子阅读','育儿经验','亲子游戏','儿童成长'],
 '教育学习':['语言学习','学习方法','知识科普','职业学习','考试备考'],
 'AI与数码':['AI工具','AI实用教程','效率工具','数码测评','软件教程'],
 '生活方式':['生活记录','家居收纳','好物分享','旅行攻略','兴趣手作'],
 '美妆穿搭':['护肤','彩妆','服饰搭配','个人形象'],
 '美食健康':['家常美食','烘焙','运动健身','健康生活'],
 '职场商业':['职场成长','个人成长','创业记录','经营经验','本地服务']
};
export default function LanePicker({value,onChange}:{value:string;onChange:(value:string)=>void}){
 const selected=value.split('、').filter(Boolean),[category,setCategory]=useState(Object.keys(lanes).find(k=>selected.some(s=>lanes[k].includes(s)))||'母婴育儿'),[custom,setCustom]=useState('');
 function toggle(v:string){const next=selected.includes(v)?selected.filter(x=>x!==v):[...selected,v];if(next.join('、').length<=300)onChange(next.join('、'));}
 return <div className="lane-picker"><select aria-label="选择赛道大类" value={category} onChange={e=>setCategory(e.target.value)}>{Object.keys(lanes).map(k=><option key={k}>{k}</option>)}</select><div className="lane-options">{lanes[category].map(s=><label key={s}><input type="checkbox" checked={selected.includes(s)} onChange={()=>toggle(s)}/>{s}</label>)}</div><div className="inline"><input aria-label="自定义细分方向" value={custom} maxLength={80} onChange={e=>setCustom(e.target.value)} placeholder="也可输入自定义方向"/><button type="button" className="btn" disabled={!custom.trim()||selected.includes(custom.trim())} onClick={()=>{toggle(custom.trim());setCustom('');}}>添加</button></div><div className="lane-selected">{selected.map(s=><button type="button" key={s} onClick={()=>toggle(s)} title="点击取消">{s} ×</button>)}</div><small>可跨大类多选。原先填写的方向会保留，点击标签可取消。</small></div>;
}
