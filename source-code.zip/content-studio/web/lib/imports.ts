import {z} from 'zod';
import {emptyMaterial,completeness,type Material} from './foundation';
import {validateRecord,migrateLegacy,checkLinks,type RecordAny} from './store';
const short=z.string().max(300),iso=z.string().datetime({offset:true});
const sourceUrl=z.string().max(2500).refine(v=>!v||/^https?:\/\//i.test(v));
export const collectionItemSchema=z.object({externalId:short.min(1),type:z.enum(['note','account','image','text']),platform:z.enum(['小红书','抖音','X']).default('小红书'),title:short.min(1),url:sourceUrl.default(''),content:z.string().max(40000).default(''),author:short.default(''),publishedAt:z.union([iso,z.literal('')]).default(''),metrics:z.object({views:z.number().min(0).nullable().optional(),likes:z.number().min(0).nullable().optional(),comments:z.number().min(0).nullable().optional(),saves:z.number().min(0).nullable().optional(),shares:z.number().min(0).nullable().optional()}).strict().default({}),tags:z.array(short).max(50).default([]),rights:z.enum(['unknown','owned','authorized','reference']).default('reference'),sample:z.boolean().default(false)}).passthrough();
export const collectionSchema=z.object({schema:z.literal('content-studio.collection'),schemaVersion:z.literal('1.0'),batchId:short.min(1),collectedAt:iso,producer:z.object({name:short.min(1),version:short.min(1)}),sample:z.boolean().default(false),items:z.array(collectionItemSchema).min(1).max(500)}).passthrough();
export type Destination={scope:'shared'|'business'|'account';businessId:string;accountId:string};
export type ImportPreview={mode:'collection'|'backup';records:RecordAny[];added:number;duplicates:number;conflicts:number;sampleCount:number;rows:{title:string;state:string;missing:string[]}[];message:string};
function canonical(url:string){if(!url)return '';const u=new URL(url);return u.origin+u.pathname.replace(/\/$/,'');}
export function materialKey(m:Material){return m.externalId?`${m.sourcePlatform}:${m.category}:${m.externalId}`:m.sourceUrl?`${m.sourcePlatform}:${m.category}:${canonical(m.sourceUrl)}`:'';}
export function parseImport(text:string,current:RecordAny[],dest:Destination):ImportPreview{
 if(text.length>8*1024*1024)throw new Error('单次JSON上限8MB，请分批导入。');
 let input;try{input=JSON.parse(text);}catch{throw new Error('JSON格式错误，请检查完整文件。');}
 if(input?.schema==='content-studio.collection'){
  const batch=collectionSchema.parse(input);
  if(dest.scope==='account'&&!current.some(r=>r.kind==='account'&&r.id===dest.accountId))throw new Error('请先选择归属账号。');
  if(dest.scope==='business'&&!current.some(r=>r.kind==='business'&&r.id===dest.businessId))throw new Error('请先选择经营资料。');
  const records=structuredClone(current),rows:ImportPreview['rows']=[];let added=0,duplicates=0,sampleCount=0;
  const bid=records.find(r=>r.kind==='importBatch'&&r.data.batchId===batch.batchId&&r.data.producer===batch.producer.name+' '+batch.producer.version)?.id||crypto.randomUUID(),stamp=new Date().toISOString();
  for(const item of batch.items){const material:Material={...emptyMaterial,title:item.title,category:item.type,sourcePlatform:item.platform,content:item.content,sourceUrl:item.url,sourceAuthor:item.author,externalId:item.externalId,publishedAt:item.publishedAt,collectedAt:batch.collectedAt,metrics:item.metrics,tags:item.tags,rights:item.rights,sample:batch.sample||item.sample,raw:item,scope:dest.scope,businessId:dest.scope==='shared'?'':dest.businessId,accountIds:dest.scope==='account'?[dest.accountId]:[],importBatchId:bid,origin:batch.producer.name};
   const previous=records.find(r=>r.kind==='material'&&materialKey(r.data)===materialKey(material));
   // Preserve every observation without silently replacing someone's edited text or ownership.
   if(previous){duplicates++;const missing=completeness(material).missing;const same=JSON.stringify(previous.data.raw)===JSON.stringify(item);
    if(!same&&!records.some(r=>r.kind==='snapshot'&&r.data.recordId===previous.id&&r.data.reason==='采集观察 '+batch.batchId))records.push({id:crypto.randomUUID(),kind:'snapshot',version:1,createdAt:stamp,updatedAt:stamp,data:{recordId:previous.id,recordKind:'material',recordVersion:previous.version,capturedAt:stamp,value:material,reason:'采集观察 '+batch.batchId}});
    rows.push({title:item.title,state:same?'重复，跳过':'重复，新观察另存快照',missing});continue;}
   const record:RecordAny={id:crypto.randomUUID(),kind:'material',data:material,version:1,createdAt:stamp,updatedAt:stamp};records.push(record);added++;if(material.sample)sampleCount++;rows.push({title:item.title,state:material.sample?'新增 · 示例':'新增',missing:completeness(material).missing});
  }
  if(!records.some(r=>r.id===bid))records.push({id:bid,kind:'importBatch',version:1,createdAt:stamp,updatedAt:stamp,data:{batchId:batch.batchId,producer:batch.producer.name+' '+batch.producer.version,importedAt:stamp,count:added,sample:batch.sample,schemaVersion:batch.schemaVersion}});
  checkLinks(records);return {mode:'collection',records,added,duplicates,conflicts:0,sampleCount,rows,message:'仅导入JSON中实际包含的资料；不下载链接中的图片或正文，不启动采集。重复资料不改归属与正文；新的观察值另存历史快照。'};
 }
 const isArray=Array.isArray(input);const version=isArray?1:input?.schemaVersion;
 if(![1,2].includes(version)||(!isArray&&!Array.isArray(input.records))||(version===2&&input.schema!=='content-studio.backup'))throw new Error('不支持此格式或版本。支持采集1.0、旧备份1和备份2。');
 const values=isArray?input:input.records;if(values.length>10000)throw new Error('备份超过10000条，请分批处理。');
 const incoming=migrateLegacy(values.map(validateRecord));if(new Set(incoming.map((r:RecordAny)=>r.id)).size!==incoming.length)throw new Error('备份内存在重复记录ID，请先修复。');
 const map=new Map<string,string>(),kept:RecordAny[]=[],sameCandidates:RecordAny[]=[],rows:ImportPreview['rows']=[];let duplicates=0,conflicts=0;
 for(const r of incoming){const previous=current.find(p=>p.id===r.id);
  if(previous&&previous.kind===r.kind&&JSON.stringify(previous.data)===JSON.stringify(r.data)){map.set(r.id,r.id);sameCandidates.push(r);duplicates++;rows.push({title:r.data.title||r.data.name||r.kind,state:'相同记录，跳过',missing:[]});continue;}
  if(previous){map.set(r.id,crypto.randomUUID());conflicts++;}else map.set(r.id,r.id);kept.push(r);
 }
 function remap(d:any){if(!d||typeof d!=='object')return d;const out=structuredClone(d);for(const k of ['accountId','businessId','taskId','topicId','draftId','metricId','fromReviewId','assetId','recordId'])if(out[k]&&map.has(out[k]))out[k]=map.get(out[k]);for(const k of ['accountIds','materialIds'])if(Array.isArray(out[k]))out[k]=out[k].map((id:string)=>map.get(id)||id);if(out.value&&typeof out.value==='object')out.value=remap(out.value);return out;}
 // An otherwise identical dependent must be copied too when one of its links was remapped.
 let changed=true;while(changed){changed=false;for(let i=sameCandidates.length-1;i>=0;i--){const r=sameCandidates[i];if(JSON.stringify(remap(r.data))!==JSON.stringify(r.data)){map.set(r.id,crypto.randomUUID());kept.push(r);sameCandidates.splice(i,1);duplicates--;conflicts++;changed=true;}}}
 const remapped=kept.map(r=>({...r,id:map.get(r.id)!,data:remap(r.data)}));
 const records=[...current,...remapped];checkLinks(records);
 rows.push(...remapped.map(r=>({title:r.data.title||r.data.name||r.kind,state:'合并新增（同ID冲突另存）',missing:[]})));
 return {mode:'backup',records,added:remapped.length,duplicates,conflicts,sampleCount:remapped.filter(r=>r.data.sample).length,rows,message:'合并恢复，不覆盖现有记录。同ID不同内容会另存并重映射关联；无法识别的版本或无效关联整批拒绝。'};
}
export const sampleCollection={schema:'content-studio.collection',schemaVersion:'1.0',batchId:'example-001',collectedAt:'2026-10-20T12:00:00Z',producer:{name:'示例文件（非真实采集）',version:'0.1.0'},sample:true,items:[{externalId:'example-note-001',type:'note',platform:'小红书',title:'示例：一次场景问题如何拆成图文选题',url:'',content:'这是一条接口示例，不是实际小红书笔记。可用来试跑资料导入、归属与任务关联。',author:'示例作者',publishedAt:'',metrics:{likes:null,saves:null},tags:['示例'],rights:'reference',sample:true}]};
