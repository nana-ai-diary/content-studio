import { z } from 'zod';
export const APP_VERSION='2.0.0';
export const STORAGE_KEY='content-studio:github:v1'; // Never rename: existing browser data lives here.
const text=z.string().max(40000), short=z.string().max(300), id=z.string().max(100), ids=z.array(id).max(500);
const url=z.string().max(2500).refine(v=>!v||/^https?:\/\//i.test(v),'链接必须是 http/https');
const platform=z.enum(['小红书','抖音','X']);
export const businessSchema=z.object({name:short.min(1),description:text,product:text,facts:text,boundaries:text,sample:z.boolean().optional()});
export const accountSchema=z.object({name:short.min(1),platform,businessId:id,positioning:text,lane:short,audience:text,tone:text,preferences:text,positiveExamples:text,negativeExamples:text,status:z.enum(['active','archived']),sample:z.boolean().optional()});
export const materialSchema=z.object({title:short.min(1),category:z.enum(['note','account','image','text']),scope:z.enum(['shared','business','account']),businessId:id,accountIds:ids,content:text,sourceUrl:url,sourceAuthor:short,externalId:short,sourcePlatform:platform,rights:z.enum(['unknown','owned','authorized','reference']),collectedAt:short,publishedAt:short,metrics:z.record(z.number().min(0).nullable()).default({}),tags:z.array(short).max(50),sample:z.boolean(),raw:z.unknown().optional(),importBatchId:id.optional(),origin:z.string().max(300).optional()});
export const taskSchema=z.object({title:short.min(1),accountId:id.min(1),businessId:id,viewpoint:text,goal:text,materialIds:ids,topicId:id,status:z.enum(['planned','writing','review','done']),sample:z.boolean().optional(),fromReviewId:id.optional()});
export const researchSchema=z.object({title:short.min(1),mode:z.enum(['account','single','topic']),accountId:id,materialIds:ids,question:text,analysis:text,sample:z.boolean().optional()});
export const reviewSchema=z.object({title:short.min(1),accountId:id,taskId:id,materialIds:ids,polarity:z.enum(['positive','negative','neutral']),observation:text,preference:text,suggestion:text,sample:z.boolean().optional(),draftId:id.optional(),metricId:id.optional()});
export const imagePlanSchema=z.object({sample:z.boolean().optional(),taskId:id.min(1),accountId:id,method:z.enum(['template','skill']),template:z.enum(['cream','mint','ink']),skillName:short,skillInstructions:text,pages:z.array(z.object({title:short,text:z.string().max(3000)})).min(1).max(12),draftId:id});
export const snapshotSchema=z.object({recordId:id,recordKind:short,recordVersion:z.number().int().positive(),capturedAt:short,value:z.unknown(),reason:short});
export const importBatchSchema=z.object({batchId:short,producer:short,importedAt:short,count:z.number().int().min(0),sample:z.boolean(),schemaVersion:short});
export const extendedSchemas={business:businessSchema,account:accountSchema,material:materialSchema,task:taskSchema,research:researchSchema,review:reviewSchema,imagePlan:imagePlanSchema,snapshot:snapshotSchema,importBatch:importBatchSchema};
export type Business=z.infer<typeof businessSchema>; export type Account=z.infer<typeof accountSchema>; export type Material=z.infer<typeof materialSchema>; export type Task=z.infer<typeof taskSchema>; export type Research=z.infer<typeof researchSchema>; export type Review=z.infer<typeof reviewSchema>; export type ImagePlan=z.infer<typeof imagePlanSchema>;
export const emptyBusiness:Business={name:'',description:'',product:'',facts:'',boundaries:''};
export const emptyAccount:Account={name:'',platform:'小红书',businessId:'',positioning:'',lane:'',audience:'',tone:'自然、具体',preferences:'',positiveExamples:'',negativeExamples:'',status:'active'};
export const emptyMaterial:Material={title:'',category:'text',scope:'shared',businessId:'',accountIds:[],content:'',sourceUrl:'',sourceAuthor:'',externalId:'',sourcePlatform:'小红书',rights:'unknown',collectedAt:'',publishedAt:'',metrics:{},tags:[],sample:false};
export const emptyTask:Task={title:'',accountId:'',businessId:'',viewpoint:'',goal:'',materialIds:[],topicId:'',status:'planned'};
export const emptyReview:Review={title:'',accountId:'',taskId:'',materialIds:[],polarity:'neutral',observation:'',preference:'',suggestion:''};
export function completeness(m:Material){const fields=[['正文',!!m.content.trim()],['来源链接',!!m.sourceUrl],['作者',!!m.sourceAuthor],['发布时间',!!m.publishedAt],['采集时间',!!m.collectedAt],['互动数据',Object.values(m.metrics).some(v=>v!==null)]] as const;return {percent:Math.round(fields.filter(x=>x[1]).length/fields.length*100),missing:fields.filter(x=>!x[1]).map(x=>x[0])};}
export function materialAvailable(m:Material,accountId:string,businessId:string){return m.scope==='shared'||(m.scope==='account'&&m.accountIds.includes(accountId))||(m.scope==='business'&&!!businessId&&m.businessId===businessId);}
