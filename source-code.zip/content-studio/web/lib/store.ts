import {z} from 'zod';
import type {Kind,StudioRecord,Draft,Profile} from './types';
import {kinds,validateData,draftTransition} from './validation';
import {STORAGE_KEY,APP_VERSION,emptyAccount,emptyBusiness,materialAvailable,type Material} from './foundation';
export type RecordAny=StudioRecord<any>;
const metadata=z.object({id:z.string().min(1).max(100),kind:z.enum([...kinds] as [Kind,...Kind[]]),version:z.number().int().positive(),createdAt:z.string().datetime({offset:true}),updatedAt:z.string().datetime({offset:true}),data:z.unknown()});
export function validateRecord(input:unknown):RecordAny {
 const r=metadata.parse(input);
 const data=r.kind==='asset'?z.object({name:z.string(),mime:z.string(),size:z.number().min(0),key:z.string()}).parse(r.data):validateData(r.kind,r.data);
 return {...r,data};
}
export function checkLinks(records:RecordAny[]) {
 const byId=new Map(records.map(r=>[r.id,r]));
 const requireKind=(id:string|undefined,ks:Kind[],label:string)=>{if(id&&(!byId.has(id)||!ks.includes(byId.get(id)!.kind)))throw new Error(`${label}引用无效：${id}`);};
 for(const r of records){
  const d=r.data;
  if(['snapshot','importBatch','profile','asset'].includes(r.kind))continue;
  requireKind(d.accountId,['account'],'账号');requireKind(d.businessId,['business'],'经营资料');requireKind(d.taskId,['task'],'任务');
  if(!(d.legacyOrphans?.draftId===d.draftId&&!byId.has(d.draftId)))requireKind(d.draftId,['draft'],'草稿');if(!(d.legacyOrphans?.topicId===d.topicId&&!byId.has(d.topicId)))requireKind(d.topicId,['topic'],'选题');requireKind(d.fromReviewId,['review'],'复盘');requireKind(d.metricId,['metric'],'表现记录');
  for(const id of d.accountIds||[])requireKind(id,['account'],'素材归属账号');
  for(const id of d.materialIds||[])requireKind(id,['material'],'证据素材');
  if(r.kind==='material'&&((d.scope==='business'&&!d.businessId)||(d.scope==='account'&&!d.accountIds.length)))throw new Error('专属素材必须指定归属');
  if(r.kind==='task'){
   const a=byId.get(d.accountId)!.data;
   if(d.businessId!==a.businessId)throw new Error('任务经营资料必须与账号一致');
   for(const id of d.materialIds)if(!materialAvailable(byId.get(id)!.data as Material,d.accountId,d.businessId))throw new Error('任务引用了其他账号的专属素材');
  }
  if(['draft','imagePlan'].includes(r.kind)&&d.taskId){const task=byId.get(d.taskId)!.data;if(d.accountId!==task.accountId)throw new Error('工作室账号与内容任务不一致');}
 }
}
export function migrateLegacy(input:RecordAny[]):RecordAny[]{
 const records=structuredClone(input), stamp=new Date().toISOString();
 const profile=records.find(r=>r.kind==='profile');
 const old=records.filter(r=>['topic','draft','reference','metric'].includes(r.kind)&&!r.data.accountId);
 if(!profile&&!old.length)return records;
 let business=records.find(r=>r.id==='business-legacy');
 if(!business){business={id:'business-legacy',kind:'business',version:1,createdAt:stamp,updatedAt:stamp,data:{...emptyBusiness,name:profile?.data.name||'历史经营资料',product:profile?.data.product||'',facts:profile?.data.facts||'',boundaries:profile?.data.forbidden||'',description:'由旧版业务配置迁移'}};records.push(business);}
 const ps=new Set<string>(['小红书',...old.map(r=>r.data.platform).filter(Boolean)]);
 const accountId=(p:string)=>'account-legacy-'+(p==='抖音'?'dy':p==='X'?'x':'xhs');
 for(const p of ps){const aid=accountId(p);if(!records.some(r=>r.id===aid))records.push({id:aid,kind:'account',version:1,createdAt:stamp,updatedAt:stamp,data:{...emptyAccount,name:(profile?.data.name||'历史账号')+' · '+p,platform:p,businessId:business.id,lane:profile?.data.lane||'',audience:profile?.data.audience||'',tone:profile?.data.tone||'',positioning:'由旧版迁移，可在账号档案中修改'}});}
 for(const r of old){const original=structuredClone(r);r.data.accountId=accountId(r.data.platform||(r.kind==='metric'?records.find(d=>d.id===r.data.draftId)?.data.platform:'')||'小红书');r.data.businessId=business.id;for(const key of ['topicId','draftId'])if(r.data[key]&&!records.some(p=>p.id===r.data[key]))r.data.legacyOrphans={...r.data.legacyOrphans,[key]:r.data[key]};if(!records.some(s=>s.kind==='snapshot'&&s.data.recordId===r.id&&s.data.reason==='旧版升级基线'))records.push(snap(original,'旧版升级基线'));}
 return records.map(validateRecord);
}
function rawRead(){return localStorage.getItem(STORAGE_KEY);}
export function fingerprint(){return rawRead()||'[]';}
function rawWrite(records:RecordAny[]){try{localStorage.setItem(STORAGE_KEY,JSON.stringify(records));}catch{throw new Error('浏览器保存失败或空间不足；原记录未覆盖，请先导出备份。');}}
export function readRecords():RecordAny[]{
 const raw=rawRead();if(!raw)return [];
 let data;try{data=JSON.parse(raw);if(!Array.isArray(data))throw new Error();data=data.map(validateRecord);}catch{throw new Error('本地记录格式有误，未修改原数据。请到数据导入导出原始记录或恢复备份。');}
 const migrated=migrateLegacy(data);
 if(JSON.stringify(migrated)!==JSON.stringify(data)){
  try{if(!localStorage.getItem(STORAGE_KEY+':before-v2'))localStorage.setItem(STORAGE_KEY+':before-v2',raw);}catch{throw new Error('升级前备份失败，未修改旧记录，请释放空间后重试。');}
  rawWrite(migrated);
 }
 return migrated;
}
async function locked<T>(fn:()=>T):Promise<T>{if(typeof navigator!=='undefined'&&navigator.locks)return navigator.locks.request('content-studio-data',fn);return fn();}
export type SaveInput={kind:Kind;data:any;id?:string;version?:number};
function snap(r:RecordAny,reason:string):RecordAny{return {id:crypto.randomUUID(),kind:'snapshot',version:1,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),data:{recordId:r.id,recordKind:r.kind,recordVersion:r.version,capturedAt:new Date().toISOString(),value:structuredClone(r.data),reason}};}
export async function saveMany(inputs:SaveInput[]):Promise<RecordAny[]> {return locked(()=>{
 const before=readRecords();let next=[...before];const results:RecordAny[]=[];
 for(const body of inputs){if(body.kind==='asset'||body.kind==='snapshot')throw new Error('此记录不能直接编辑');
 const previous=next.find(r=>r.id===body.id);
 if(body.id&&!previous)throw new Error('记录不存在');
 if(previous&&(previous.kind!==body.kind||previous.version!==body.version))throw new Error('记录已在其他页面更新，请刷新后重试');
 const inputData={...body.data};if(previous?.data.sample||next.some(a=>a.kind==='account'&&a.id===inputData.accountId&&a.data.sample))inputData.sample=true;if(['task','draft','research','review'].includes(body.kind)&&next.some(m=>(inputData.materialIds||[]).includes(m.id)&&m.data.sample))inputData.sample=true;let data=validateData(body.kind,inputData);const now=new Date().toISOString();
 if(body.kind==='draft')data=draftTransition(previous?.data||null,data as Draft,now);
 const record:RecordAny={id:previous?.id||crypto.randomUUID(),kind:body.kind,data,version:(previous?.version||0)+1,createdAt:previous?.createdAt||now,updatedAt:now};
 if(previous&&!next.some(r=>r.kind==='snapshot'&&r.data.recordId===previous.id&&r.data.recordVersion===previous.version))next.push(snap(previous,'更新前'));
 next=[record,...next.filter(r=>r.id!==record.id)];
 if(!['snapshot','importBatch'].includes(record.kind))next.push(snap(record,'保存'));
 results.push(record);
 }
 checkLinks(next);rawWrite(next);return results;
});}
export async function deleteRecord(id:string,version:number){return locked(()=>{const records=readRecords(),r=records.find(r=>r.id===id);if(!r||r.version!==version)throw new Error('记录已改变，请刷新后重试');if(['snapshot','importBatch'].includes(r.kind))throw new Error('历史记录不可直接删除');
 const next=records.filter(x=>x.id!==id);
 try{checkLinks(next);}catch{throw new Error('这条记录仍被账号、任务、草稿或证据引用，请先解除关联。');}
 if(!next.some(x=>x.kind==='snapshot'&&x.data.recordId===id&&x.data.recordVersion===r.version))next.push(snap(r,'删除前'));
 rawWrite(next);
 });}
export function exportBackup(){return {schema:'content-studio.backup',schemaVersion:2,appVersion:APP_VERSION,exportedAt:new Date().toISOString(),records:readRecords()};}
export function exportRaw(){return {current:rawRead(),beforeV2:localStorage.getItem(STORAGE_KEY+':before-v2'),beforeImport:localStorage.getItem(STORAGE_KEY+':before-import')};}
export async function commitImport(records:RecordAny[],expected:string){return locked(()=>{if(fingerprint()!==expected)throw new Error('预览后本地记录发生变化，请重新预览再导入。');checkLinks(records);
 try{localStorage.setItem(STORAGE_KEY+':before-import',fingerprint());}catch{throw new Error('导入前备份失败，未写入数据。');}
 rawWrite(records);
 });}
