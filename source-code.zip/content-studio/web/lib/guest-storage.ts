import {readRecords,saveMany,deleteRecord} from './store';
export async function guestApi(path:string,options?:RequestInit):Promise<any>{
 if(path==='/api/status')return {aiConfigured:false,model:'',storage:false,uploads:false,collectorConnected:false};
 if(path.startsWith('/api/hotspots'))throw new Error('采集器未接通，请到数据导入上传独立采集工具的JSON结果。');
 if(path!=='/api/records')throw new Error('此在线功能尚未接通，可使用外部AI并导回结果。');
 const method=options?.method||'GET';if(method==='GET')return {records:readRecords()};
 const body=JSON.parse(String(options?.body||'{}'));
 if(method==='DELETE'){await deleteRecord(body.id,body.version);return {ok:true};}
 if(method==='POST')return {record:(await saveMany([body]))[0]};throw new Error('不支持的操作');
}
