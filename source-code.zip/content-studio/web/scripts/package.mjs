import fs from 'node:fs';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..'),docs=path.join(root,'docs'),out=path.resolve(root,'..');
let html=fs.readFileSync(path.join(docs,'index.html'),'utf8');
for(const match of [...html.matchAll(/(?:src|href)="(\.\/assets\/[^\"]+)"/g)]){
 const ref=match[1],content=fs.readFileSync(path.join(docs,ref),'utf8');
 const esc=ref.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 html=ref.endsWith('.js')?html.replace(new RegExp('<script[^>]*src="'+esc+'"[^>]*></script>'),()=>'<script type="module">'+content.replaceAll('</script','<\\/script')+'</script>'):html.replace(new RegExp('<link[^>]*href="'+esc+'"[^>]*>'),()=>'<style>'+content+'</style>');
}
if(/(?:src|href)="\.\/assets\//.test(html))throw new Error('Unbundled assets remain');
fs.writeFileSync(path.join(out,'index.html'),html);
for(const name of fs.readdirSync(path.join(root,'public')))if(fs.statSync(path.join(root,'public',name)).isFile())fs.copyFileSync(path.join(root,'public',name),path.join(out,name));
console.log('Packaged root index.html and public documentation');
