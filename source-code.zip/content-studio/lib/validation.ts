import { z } from "zod";
import type { Draft, Kind } from "./types";
const str=z.string().max(40000), short=z.string().max(300), platform=z.enum(["小红书","抖音","X"]);
const url=z.string().max(2500).refine(v=>!v||/^https?:\/\//i.test(v),"链接需使用 http 或 https");
export const profileSchema=z.object({name:short.min(1),lane:short,audience:str,product:str,goal:short,tone:str,forbidden:str,facts:str,language:short,platforms:z.array(platform).min(1).max(3),knowledgeEnabled:z.literal(false)});
export const topicSchema=z.object({title:short.min(1),angle:str,reason:str,source:short,url,excerpt:str,platforms:z.array(platform).min(1).max(3),pillar:short,status:z.enum(["new","selected","archived"]),sourceTime:short.optional(),fetchedAt:short.optional(),sample:z.boolean().optional(),generatedBy:short.optional()});
export const referenceSchema=z.object({title:short.min(1),platform,account:short,url,text:str,analysis:str,sample:z.boolean().optional()});
export const draftSchema=z.object({topicId:short,platform,format:z.enum(["text","cards","video"]),title:short.min(1),body:str,tags:z.string().max(2000),cover:short,pages:z.array(z.object({title:short,text:z.string().max(3000)})).min(1).max(12),script:str,status:z.enum(["draft","review","approved","scheduled","published"]),scheduledAt:short,publishUrl:url,theme:z.enum(["cream","mint","ink"]),assetId:short,generatedBy:short,source:str,reviewNote:str,approvedAt:short.optional(),publishedAt:short.optional()});
export const metricSchema=z.object({draftId:short.min(1),date:z.string().regex(/^\d{4}-\d{2}-\d{2}$/),views:z.number().int().min(0).max(1e12),likes:z.number().int().min(0).max(1e12),comments:z.number().int().min(0).max(1e12),saves:z.number().int().min(0).max(1e12),inquiries:z.number().int().min(0).max(1e12)});
export const kinds=["profile","topic","reference","draft","asset","metric"] as const;
export const schemas={profile:profileSchema,topic:topicSchema,reference:referenceSchema,draft:draftSchema,metric:metricSchema};
export function validateData(kind:Kind,data:unknown){if(kind==='asset')throw new Error('图片请通过上传接口添加');return schemas[kind].parse(data);}
export function draftTransition(previous:Draft|null,next:Draft,now=new Date().toISOString()):Draft {
 const protectedFields=(d:Draft)=>JSON.stringify([d.platform,d.format,d.title,d.body,d.tags,d.cover,d.pages,d.script,d.theme,d.assetId,d.source]);
 const changed=previous && protectedFields(previous)!==protectedFields(next);
 if(!previous && next.status!=="draft")throw new Error("新内容需从草稿开始");
 if(previous?.status==="published" && changed)throw new Error("已发布内容请复制为新草稿，保留原发布记录");
 if(changed){next.status="draft";next.scheduledAt="";delete next.approvedAt;}
 else if(next.status==="approved" && previous?.status!=="approved") {
  if(previous?.status!=="review")throw new Error("请先提交审核");
  const publishText=[next.title,next.body,next.tags,...(next.format==="text"?[]:next.format==="cards"?[next.cover,...next.pages.map(p=>p.title+p.text)]:[next.script])].join("\n");
  if(/\[.*?(待补充|补充|待核实).*?\]/.test(publishText))throw new Error("内容仍有待补充项，请完善后再批准");
  next.approvedAt=now;
 }
 else if(next.status==="scheduled") {
  if(!["approved","scheduled"].includes(previous?.status||""))throw new Error("审核批准后才可排期");
  if(!next.scheduledAt || !Number.isFinite(Date.parse(next.scheduledAt)) || Date.parse(next.scheduledAt)<=Date.parse(now))throw new Error("请选择未来的排期时间");
 }
 else if(next.status==="published" && previous?.status!=="published") {
  if(!["approved","scheduled"].includes(previous?.status||""))throw new Error("审核批准后才可登记发布");
  if(!next.publishUrl)throw new Error("请填写实际发布链接");next.publishedAt=now;
 }
 else if(previous?.status==="published" && next.status!=="published")throw new Error("已发布记录不能退回草稿，请复制新版本");
 else if(next.status==="review" && previous && !["draft","review"].includes(previous.status))throw new Error("已批准内容需先退回草稿再审核");
 if(next.status==="draft"){next.scheduledAt="";delete next.approvedAt;delete next.publishedAt;}
 return next;
}
