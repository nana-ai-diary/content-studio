import type { Draft, Kind, StudioRecord } from './types';
import { kinds, validateData, draftTransition } from './validation';

const storageKey = 'content-studio:github:v1';
function read(): StudioRecord<any>[] {
  try {
    const stored = localStorage.getItem(storageKey);
    if (!stored) return [];
    const records = JSON.parse(stored);
    if (!Array.isArray(records)) throw new Error();
    return records;
  } catch {
    throw new Error('无法读取浏览器记录，请允许本站使用本地存储；已有数据不会被覆盖。');
  }
}
function write(records: StudioRecord<any>[]) {
  try { localStorage.setItem(storageKey, JSON.stringify(records)); }
  catch { throw new Error('浏览器保存失败，可能空间不足或禁止存储。请先导出备份。'); }
}

// Anonymous work stays on this device. Never use the owner's server identity.
export async function guestApi(path: string, options?: RequestInit): Promise<any> {
  if (path === '/api/status') return { aiConfigured: false, model: '', storage: false, uploads: false };
  if (path.startsWith('/api/hotspots')) throw new Error('请打开来源网站或手动导入热点；GitHub Pages 静态版不提供在线获取服务。');
  if (path !== '/api/records') throw new Error('GitHub Pages 静态版不提供此云端功能，可以编辑文字、制作图文并导出。');
  const records = read();
  const method = options?.method || 'GET';
  if (method === 'GET') return { records };
  const body = JSON.parse(String(options?.body || '{}'));
  const previous = records.find(r => r.id === body.id);
  if (body.id && !previous) throw new Error('记录不存在，请刷新后重试');
  if (previous && previous.version !== body.version) throw new Error('其他页面已修改这条记录，请刷新后重试');
  if (method === 'DELETE') {
    if (!previous) throw new Error('记录不存在');
    write(records.filter(r => r.id !== body.id));
    return { ok: true };
  }
  if (method !== 'POST' || !kinds.includes(body.kind) || body.kind === 'asset') throw new Error('记录类型有误');
  if (previous && previous.kind !== body.kind) throw new Error('不能更改记录类型');
  const kind = body.kind as Kind;
  let data = validateData(kind, body.data);
  const now = new Date().toISOString();
  if (kind === 'draft') data = draftTransition(previous?.data || null, data as Draft, now);
  const record = { id: previous?.id || crypto.randomUUID(), kind, data, version: (previous?.version || 0) + 1, createdAt: previous?.createdAt || now, updatedAt: now };
  write([record, ...records.filter(r => r.id !== record.id)]);
  return { record };
}
